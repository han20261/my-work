# DESIGN.md

## Direction & Layout

**Product**: Forge — a vibecoding workbench. Users describe an H5 app in natural language, the backend generates a complete single-file HTML app, and the result renders instantly in an iframe with the source code visible beside it.

**Mood**: A dark workshop, not a marketing site. Precise, tool-like, quietly confident. It should feel like an instrument panel for building things — dense but calm, never playful or decorative.

**Defining visual idea (first screen)**: A raw ink canvas split into three vertical lanes — project rail, conversation column, and a live device frame glowing over the generated app. The accent is a hot coral used only on action and live-state signals, so the eye always knows where "work happens".

**Visual reference**: Linear's information density and DevTools' restrained dark chrome — not claimed from an opened source, but as a described target.

**Hierarchy & focal point**: The live preview frame is the focal point. The prompt composer is the primary action below the conversation. Everything else is supporting chrome.

**Composition**: Full-bleed app shell, no centered card stack, no hero. Three lanes on desktop — 248px rail / 400px conversation / flexible preview. `max-w-[1800px]` centered shell with 16px outer gutter. Section gap 16px, lane inner padding 20px, vertical rhythm in 8px steps.

**Breakpoints**:
- `>=1280px`: three lanes side by side, rail visible.
- `768–1279px`: rail collapses into a top-left dropdown, two lanes (conversation 380px + preview).
- `<768px`: single lane with a segmented switcher (Chat / Preview / Code); composer sticks to the bottom above the keyboard.

**Do / Don't**
- Do: keep the preview frame visible whenever the user is not actively typing; show run state (building / error / ready) as a thin status strip.
- Do: monospace for code, generated-app titles, and status values.
- Don't: colored left-border cards, glassmorphism, gradient buttons, blue-purple gradients, centered hero sections, drop shadows heavier than 24px blur.
- Don't: replace the live iframe with a screenshot or placeholder when code exists.

## Tokens

**Colors (dark only)**
- `--background` ink `#0B0E14` — app canvas.
- `--card` panel `#141A24` — lanes, composer, device chrome.
- `--muted` raised `#1C2331` — inputs, code gutter, inactive tabs.
- `--border` `#252D3D` — 1px separators only.
- `--foreground` `#E9EDF5`; `--muted-foreground` `#8B95A7`.
- `--primary` coral `#FF6A3D` (hover `#FF835C`, foreground `#12100E`) — Generate button, active tab underline, live dot.
- Success `#4ED8A0`, warning `#F5C452`, destructive `#EF5D5D` — status strip and error banner only.
- Accent coral is scarce: at most one coral element per lane.

**Typography**
- Display/UI: `Space Grotesk` (fallback `system-ui`) — headings 600, UI labels 500.
- Body: `IBM Plex Sans` (fallback `system-ui`) — 14px/1.6.
- Mono: `JetBrains Mono` (fallback `ui-monospace`) — code 12.5px/1.65, titles 13px, status 11px uppercase tracking `0.08em`.
- Scale: lane title 12px uppercase, project name 15px/1.3 600, message body 14px/1.6, caption 12px.

**Spacing & shapes**
- Scale: 4 / 8 / 12 / 16 / 20 / 24 / 32.
- Radii: panels 14px, inputs & buttons 10px, pills 999px, code blocks 10px.
- Icon buttons are 36px square with 10px radius; tap targets never under 40px on mobile.

**Elevation**
- Hierarchy comes from surface lightness and 1px borders, not shadows. Only overlays (dialogs, toasts) get `0 24px 48px -24px rgba(0,0,0,0.75)`.
- Sticky composer: panel surface plus a `--border` top line.

## Shared Patterns & States

**Components**
- `ProjectRail`: list rows with title + relative time; active row uses muted surface and a 2px coral left marker inside the row (not a card border).
- `ConversationPanel`: alternating message blocks — user turns on raised surface, assistant turns transparent with a coral status text; each generation shows the summary sentence.
- `Composer`: textarea + model badge + coral Generate button; `Cmd/Ctrl + Enter` submits.
- `PreviewToolbar`: device width toggles (mobile 390 / tablet 768 / desktop 100%), reload, open in new tab, download.
- `CodeView`: mono block with copy button; read-only.
- Empty state: dashed `--border` frame over the ink canvas with one line of guidance and 3 example prompt pills.

**States & interactions**
- Generate: button shows spinner and disabled state; status strip reads `building…` in coral; conversation gets a pulsing assistant placeholder.
- Error: red status strip with the backend message plus a `Retry` button; loading state always resets.
- Ready: green dot, status shows version number and elapsed time.
- Hover: surfaces lighten by one step, 120ms; press: scale 0.985.
- Empty/not-logged-in/loading/error are all reachable and distinct.
- Motion: 120ms `ease-out` for hovers, 180ms for lane and tab transitions, one 2s pulse for the live dot. No entrance animations; content is visible on first paint.

**Accessibility**
- Minimum 40px tap targets, visible `--primary` focus ring (`2px` offset 2px), accessible names on all icon-only buttons, form errors as text not color alone, iframe titled.

## Media

No photography or illustration: this is an operational tool where the user's generated app is the only imagery that matters. The preview iframe, the coral live dot, and typographic craft carry the visual interest. Abstract gradient art would compete with user content and is explicitly excluded.
