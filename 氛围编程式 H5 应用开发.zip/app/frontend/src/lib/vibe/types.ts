export type DeviceWidth = 'mobile' | 'tablet' | 'desktop';

/** One generated revision of a project. */
export interface VibeVersion {
  id: string;
  code: string;
  prompt: string;
  summary: string;
  title: string;
  createdAt: number;
}

export interface VibeMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: number;
  status: 'pending' | 'done' | 'error';
  versionId?: string;
}

export interface VibeProject {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  versions: VibeVersion[];
  messages: VibeMessage[];
}

export interface GenerateAppResult {
  code: string;
  title: string;
  summary: string;
  model: string;
}

export const EXAMPLE_PROMPTS = [
  '做一个番茄钟计时器，有开始/暂停和专注记录统计',
  '做一个记账小工具，能添加收支并显示本月结余',
  '做一个猜数字小游戏，带提示和尝试次数',
  '做一个待办清单，支持勾选完成和本地保存',
];

export const DEVICE_WIDTHS: Record<DeviceWidth, string> = {
  mobile: '390px',
  tablet: '768px',
  desktop: '100%',
};
