import { useCallback, useState } from 'react';
import { client } from '@/lib/api';
import type { GenerateAppResult, VibeMessage } from './types';

export const errorDetail = (error: any): string =>
  error?.data?.detail || error?.response?.data?.detail || error?.message || '请求失败，请重试';

interface GenerateParams {
  prompt: string;
  mode: 'create' | 'edit';
  appName?: string;
  currentCode?: string;
  history: VibeMessage[];
}

/** Calls the Atoms Cloud generator endpoint that returns a complete single-file H5 app. */
export function useVibeGenerator() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generate = useCallback(async (params: GenerateParams): Promise<GenerateAppResult> => {
    setIsGenerating(true);
    setError(null);
    try {
      const response = await client.apiCall.invoke({
        url: '/api/v1/vibe/generate',
        method: 'POST',
        data: {
          prompt: params.prompt,
          mode: params.mode,
          app_name: params.appName,
          current_code: params.currentCode,
          history: params.history.map((message) => ({ role: message.role, content: message.content })),
        },
        options: { timeout: 600_000 },
      });

      const data = response?.data as GenerateAppResult | undefined;
      if (!data?.code) {
        throw new Error('生成结果为空，请重试');
      }
      return data;
    } catch (e: any) {
      const detail = errorDetail(e);
      setError(detail);
      throw new Error(detail);
    } finally {
      setIsGenerating(false);
    }
  }, []);

  return { isGenerating, error, setError, generate };
}
