import { useCallback, useEffect, useState } from 'react';
import type { VibeMessage, VibeProject, VibeVersion } from './types';

const STORAGE_KEY = 'forge:vibe-projects:v1';

const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

function loadProjects(): VibeProject[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as VibeProject[]) : [];
  } catch {
    return [];
  }
}

function persist(projects: VibeProject[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
  } catch {
    // Storage can be unavailable (private mode / blocked origin) — the session still works in memory.
  }
}

export function createProject(title = '未命名项目'): VibeProject {
  const now = Date.now();
  return { id: uid(), name: title, createdAt: now, updatedAt: now, versions: [], messages: [] };
}

export function createMessage(role: VibeMessage['role'], content: string): VibeMessage {
  return { id: uid(), role, content, createdAt: Date.now(), status: role === 'assistant' ? 'pending' : 'done' };
}

export function createVersion(payload: Omit<VibeVersion, 'id' | 'createdAt'>): VibeVersion {
  return { ...payload, id: uid(), createdAt: Date.now() };
}

/** Project state kept in browser storage — the whole workbench state lives here. */
export function useVibeStore() {
  const [projects, setProjects] = useState<VibeProject[]>(() => loadProjects());
  const [activeId, setActiveId] = useState<string | null>(() => loadProjects()[0]?.id ?? null);

  useEffect(() => {
    persist(projects);
  }, [projects]);

  const patchProject = useCallback((projectId: string, patch: (project: VibeProject) => VibeProject) => {
    setProjects((prev) =>
      prev.map((project) => (project.id === projectId ? { ...patch(project), updatedAt: Date.now() } : project)),
    );
  }, []);

  const addProject = useCallback((title?: string) => {
    const project = createProject(title);
    setProjects((prev) => [project, ...prev]);
    setActiveId(project.id);
    return project;
  }, []);

  const removeProject = useCallback((projectId: string) => {
    setProjects((prev) => {
      const next = prev.filter((project) => project.id !== projectId);
      setActiveId((current) => (current === projectId ? next[0]?.id ?? null : current));
      return next;
    });
  }, []);

  const appendMessage = useCallback(
    (projectId: string, message: VibeMessage) => {
      patchProject(projectId, (project) => ({ ...project, messages: [...project.messages, message] }));
    },
    [patchProject],
  );

  const updateMessage = useCallback(
    (projectId: string, messageId: string, patch: Partial<VibeMessage>) => {
      patchProject(projectId, (project) => ({
        ...project,
        messages: project.messages.map((message) => (message.id === messageId ? { ...message, ...patch } : message)),
      }));
    },
    [patchProject],
  );

  const appendVersion = useCallback(
    (projectId: string, version: VibeVersion, title?: string) => {
      patchProject(projectId, (project) => ({
        ...project,
        name: title?.trim() ? title.trim() : project.name,
        versions: [...project.versions, version],
      }));
    },
    [patchProject],
  );

  const activeProject = projects.find((project) => project.id === activeId) ?? null;

  return {
    projects,
    activeProject,
    activeId,
    setActiveId,
    addProject,
    removeProject,
    appendMessage,
    updateMessage,
    appendVersion,
  };
}

export type VibeStore = ReturnType<typeof useVibeStore>;
