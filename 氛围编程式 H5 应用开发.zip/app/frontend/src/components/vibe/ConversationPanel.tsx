import { Bot, User } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import type { VibeMessage } from '@/lib/vibe/types';

const formatClock = (timestamp: number) =>
  new Date(timestamp).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });

const MessageBlock = ({ message }: { message: VibeMessage }) => {
  const isUser = message.role === 'user';
  return (
    <div className={cn('flex gap-3', isUser ? 'flex-row-reverse text-right' : 'flex-row')}>
      <div
        className={cn(
          'mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-border',
          isUser ? 'bg-muted' : 'bg-card',
        )}
        aria-hidden
      >
        {isUser ? <User className="h-4 w-4 text-muted-foreground" /> : <Bot className="h-4 w-4 text-primary" />}
      </div>

      <div className={cn('min-w-0 flex-1', isUser && 'flex flex-col items-end')}>
        <div className="label-mono flex items-center gap-2 text-muted-foreground">
          <span>{isUser ? 'You' : 'Forge'}</span>
          <span>{formatClock(message.createdAt)}</span>
        </div>
        <div
          className={cn(
            'mt-2 rounded-[10px] px-3.5 py-2.5 text-[14px] leading-relaxed',
            isUser ? 'inline-block bg-muted text-foreground' : 'text-foreground',
            message.status === 'pending' && 'text-muted-foreground',
            message.status === 'error' && 'text-destructive',
          )}
        >
          {message.status === 'pending' ? (
            <span className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 animate-live rounded-full bg-primary" />
              正在构建应用…
            </span>
          ) : (
            message.content
          )}
        </div>
      </div>
    </div>
  );
};

interface ConversationPanelProps {
  messages: VibeMessage[];
  isGenerating: boolean;
}

export const ConversationPanel = ({ messages, isGenerating }: ConversationPanelProps) => (
  <ScrollArea className="min-h-0 flex-1">
    <div className="flex flex-col gap-5 px-5 py-5">
      {messages.length === 0 ? (
        <div className="rounded-[14px] border border-dashed border-border px-5 py-8">
          <p className="font-display text-[15px] font-semibold">用一句话描述你的 H5 应用</p>
          <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
            例如“做一个番茄钟”，生成后可继续用自然语言修改，右侧即时预览。
          </p>
        </div>
      ) : (
        messages.map((message) => <MessageBlock key={message.id} message={message} />)
      )}

      {isGenerating && messages[messages.length - 1]?.status !== 'pending' && (
        <p className="flex items-center gap-2 text-[13px] text-muted-foreground">
          <span className="h-1.5 w-1.5 animate-live rounded-full bg-primary" />
          正在处理修改…
        </p>
      )}
    </div>
  </ScrollArea>
);
