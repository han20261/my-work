import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, Copy, Download, ExternalLink, Loader2, Monitor, RotateCw, Smartphone, Tablet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { DEVICE_WIDTHS, type DeviceWidth } from '@/lib/vibe/types';

const DEVICE_ICONS: Record<DeviceWidth, typeof Monitor> = {
  mobile: Smartphone,
  tablet: Tablet,
  desktop: Monitor,
};

const countLines = (code: string) => code.split('\n').length;

interface PreviewPanelProps {
  code: string;
  projectName: string;
  versionCount: number;
  isGenerating: boolean;
  status: { kind: 'idle' | 'ready' | 'error'; text: string };
  buildMs: number | null;
  onRetry: () => void;
  canRetry: boolean;
}

export const PreviewPanel = ({
  code,
  projectName,
  versionCount,
  isGenerating,
  status,
  buildMs,
  onRetry,
  canRetry,
}: PreviewPanelProps) => {
  const [device, setDevice] = useState<DeviceWidth>('mobile');
  const [tab, setTab] = useState<'preview' | 'code'>('preview');
  const [reloadKey, setReloadKey] = useState(0);
  const [copied, setCopied] = useState(false);
  const copyTimer = useRef<number | null>(null);

  const objectUrl = useMemo(() => {
    if (!code) return '';
    return URL.createObjectURL(new Blob([code], { type: 'text/html' }));
  }, [code]);

  useEffect(() => () => {
    if (objectUrl) URL.revokeObjectURL(objectUrl);
  }, [objectUrl]);

  useEffect(() => () => {
    if (copyTimer.current) window.clearTimeout(copyTimer.current);
  }, []);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      copyTimer.current = window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = `${projectName.replace(/[\\/:*?"<>|]/g, '-') || 'vibe-app'}.html`;
    link.click();
  };

  const statusTone =
    status.kind === 'error' ? 'text-destructive' : status.kind === 'ready' ? 'text-[#4ED8A0]' : 'text-muted-foreground';

  return (
    <section className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-[14px] border border-border bg-card">
      <div className="flex flex-wrap items-center gap-2 border-b border-border px-3 py-2.5">
        <Tabs value={tab} onValueChange={(value) => setTab(value as 'preview' | 'code')}>
          <TabsList className="h-9 bg-muted p-0.5">
            <TabsTrigger value="preview" className="h-8 px-3 text-[13px]">
              预览
            </TabsTrigger>
            <TabsTrigger value="code" className="h-8 px-3 text-[13px]">
              代码
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {tab === 'preview' && (
          <div className="flex items-center gap-1 rounded-[10px] bg-muted p-0.5" role="group" aria-label="设备宽度">
            {(Object.keys(DEVICE_WIDTHS) as DeviceWidth[]).map((key) => {
              const Icon = DEVICE_ICONS[key];
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setDevice(key)}
                  aria-label={`切换为 ${key} 宽度`}
                  aria-pressed={device === key}
                  className={cn(
                    'flex h-8 w-9 items-center justify-center rounded-[8px] transition-colors',
                    device === key ? 'bg-card text-primary' : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  <Icon className="h-4 w-4" />
                </button>
              );
            })}
          </div>
        )}

        <div className="ml-auto flex items-center gap-1">
          {tab === 'preview' && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setReloadKey((key) => key + 1)}
              disabled={!code}
              className="h-9 gap-1.5 px-2 text-[13px]"
            >
              <RotateCw className="h-3.5 w-3.5" />
              重载
            </Button>
          )}
          <Button
            size="sm"
            variant="ghost"
            onClick={handleCopy}
            disabled={!code}
            className="h-9 gap-1.5 px-2 text-[13px]"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-[#4ED8A0]" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? '已复制' : '复制'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => objectUrl && window.open(objectUrl, '_blank', 'noopener')}
            disabled={!code}
            className="h-9 gap-1.5 px-2 text-[13px]"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            新标签
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleDownload}
            disabled={!code}
            className="h-9 gap-1.5 px-2 text-[13px]"
          >
            <Download className="h-3.5 w-3.5" />
            下载
          </Button>
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-auto bg-[#0B0E14] p-3">
        {!code && !isGenerating && (
          <div className="flex h-full min-h-[320px] items-center justify-center rounded-[12px] border border-dashed border-border">
            <div className="max-w-[320px] px-6 text-center">
              <p className="font-display text-[15px] font-semibold">
                {status.kind === 'error' ? '生成失败' : '等待生成'}
              </p>
              <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{status.text}</p>
              {canRetry && status.kind === 'error' && (
                <Button size="sm" onClick={onRetry} className="mt-4">
                  重试
                </Button>
              )}
            </div>
          </div>
        )}

        {!code && isGenerating && (
          <div className="flex h-full min-h-[320px] flex-col items-center justify-center gap-3 rounded-[12px] border border-border bg-card">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
            <p className="label-mono text-muted-foreground">building…</p>
          </div>
        )}

        {code && tab === 'preview' && (
          <div className="flex min-h-full justify-center">
            <iframe
              key={reloadKey}
              title={`${projectName} 预览`}
              srcDoc={code}
              sandbox="allow-scripts allow-forms allow-modals allow-popups"
              className="h-[calc(100vh-320px)] min-h-[420px] rounded-[12px] border border-border bg-white"
              style={{ width: DEVICE_WIDTHS[device], maxWidth: '100%' }}
            />
          </div>
        )}

        {code && tab === 'code' && (
          <pre className="overflow-auto rounded-[12px] border border-border bg-card p-4 text-[12.5px] leading-[1.65]">
            <code className="font-mono text-foreground">{code}</code>
          </pre>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-3 border-t border-border px-4 py-2">
        <span className="flex items-center gap-2">
          <span
            className={cn(
              'h-1.5 w-1.5 rounded-full',
              status.kind === 'error'
                ? 'bg-destructive'
                : status.kind === 'ready'
                  ? 'bg-[#4ED8A0] animate-live'
                  : 'bg-muted-foreground',
            )}
          />
          <span className={cn('label-mono', statusTone)}>{status.text}</span>
        </span>
        <span className="label-mono text-muted-foreground">
          {code ? `v${versionCount} · ${countLines(code)} 行` : '—'}
        </span>
        {buildMs !== null && <span className="label-mono text-muted-foreground">{(buildMs / 1000).toFixed(1)}s</span>}
        {status.kind === 'error' && canRetry && (
          <Button size="sm" variant="outline" onClick={onRetry} className="ml-auto h-8 border-border !bg-transparent text-[13px] hover:!bg-accent">
            重试
          </Button>
        )}
      </div>
    </section>
  );
};
