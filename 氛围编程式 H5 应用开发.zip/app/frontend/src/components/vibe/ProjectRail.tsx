import { ChevronDown, Hammer, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import type { VibeProject } from '@/lib/vibe/types';

const formatTime = (timestamp: number) => {
  const minutes = Math.floor((Date.now() - timestamp) / 60000);
  if (minutes < 1) return '刚刚';
  if (minutes < 60) return `${minutes} 分钟前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} 小时前`;
  return new Date(timestamp).toLocaleDateString('zh-CN', { month: 'numeric', day: 'numeric' });
};

interface ProjectListProps {
  projects: VibeProject[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
}

const ProjectList = ({ projects, activeId, onSelect, onDelete }: ProjectListProps) => (
  <div className="space-y-1">
    {projects.map((project) => {
      const isActive = project.id === activeId;
      return (
        <div
          key={project.id}
          className={cn('group flex items-center gap-1 rounded-[10px] pr-1 transition-colors', isActive && 'bg-muted')}
        >
          {isActive && <span className="ml-1 h-6 w-[2px] shrink-0 rounded-full bg-primary" />}
          <button
            type="button"
            onClick={() => onSelect(project.id)}
            className="min-w-0 flex-1 px-3 py-2.5 text-left"
            aria-current={isActive}
          >
            <p className="truncate font-display text-[15px] font-semibold leading-tight">{project.name}</p>
            <p className="label-mono mt-1 truncate text-muted-foreground">
              v{project.versions.length} · {formatTime(project.updatedAt)}
            </p>
          </button>
          <button
            type="button"
            onClick={() => onDelete(project.id)}
            aria-label={`删除项目 ${project.name}`}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px] text-muted-foreground opacity-0 transition hover:bg-accent hover:text-destructive focus-visible:opacity-100 group-hover:opacity-100"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      );
    })}
    {projects.length === 0 && (
      <p className="px-3 py-6 text-center text-[13px] leading-relaxed text-muted-foreground">
        还没有项目
        <br />
        在右侧描述你的第一个应用
      </p>
    )}
  </div>
);

interface ProjectRailProps extends ProjectListProps {
  className?: string;
  onCreate: () => void;
}

export const ProjectRail = ({ className, onCreate, ...list }: ProjectRailProps) => (
  <aside className={cn('flex min-h-0 flex-col rounded-[14px] border border-border bg-card', className)}>
    <div className="flex items-center justify-between px-4 pb-3 pt-4">
      <span className="label-mono text-muted-foreground">Projects</span>
      <Button size="sm" variant="ghost" onClick={onCreate} className="h-8 gap-1 px-2 text-[13px]">
        <Plus className="h-3.5 w-3.5" />
        新建
      </Button>
    </div>
    <ScrollArea className="min-h-0 flex-1 px-2 pb-3">
      <ProjectList {...list} />
    </ScrollArea>
  </aside>
);

interface ProjectMenuProps extends ProjectListProps {
  onCreate: () => void;
  activeName: string;
}

/** Compact project switcher used below the xl breakpoint. */
export const ProjectMenu = ({ activeName, onCreate, ...list }: ProjectMenuProps) => (
  <DropdownMenu>
    <DropdownMenuTrigger asChild>
      <Button
        variant="outline"
        className="!bg-transparent max-w-[220px] gap-2 border-border px-3 text-[13px] hover:!bg-accent"
      >
        <Hammer className="h-3.5 w-3.5 text-primary" />
        <span className="truncate">{activeName}</span>
        <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
      </Button>
    </DropdownMenuTrigger>
    <DropdownMenuContent align="start" className="w-[260px] border-border bg-popover">
      <DropdownMenuLabel className="label-mono text-muted-foreground">Projects</DropdownMenuLabel>
      <DropdownMenuSeparator />
      <DropdownMenuItem onSelect={onCreate} className="gap-2">
        <Plus className="h-4 w-4" />
        新建项目
      </DropdownMenuItem>
      <DropdownMenuSeparator />
      {list.projects.map((project) => (
        <DropdownMenuItem
          key={project.id}
          onSelect={() => list.onSelect(project.id)}
          className="justify-between gap-3"
        >
          <span className="truncate">{project.name}</span>
          <span className="label-mono shrink-0 text-muted-foreground">v{project.versions.length}</span>
        </DropdownMenuItem>
      ))}
    </DropdownMenuContent>
  </DropdownMenu>
);
