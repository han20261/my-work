import { useMemo, useRef, useState } from 'react';
import { ArrowUp, Hammer, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { ConversationPanel } from '@/components/vibe/ConversationPanel';
import { PreviewPanel } from '@/components/vibe/PreviewPanel';
import { ProjectMenu, ProjectRail } from '@/components/vibe/ProjectRail';
import { createMessage, createVersion, useVibeStore } from '@/lib/vibe/store';
import { EXAMPLE_PROMPTS } from '@/lib/vibe/types';
import { useVibeGenerator } from '@/lib/vibe/useVibeGenerator';

const Index = () => {
  const store = useVibeStore();
  const { isGenerating, generate } = useVibeGenerator();
  const [prompt, setPrompt] = useState('');
  const [mobileLane, setMobileLane] = useState<'chat' | 'preview'>('chat');
  const [status, setStatus] = useState<{ kind: 'idle' | 'ready' | 'error'; text: string }>({
    kind: 'idle',
    text: 'idle',
  });
  const [buildMs, setBuildMs] = useState<number | null>(null);
  const lastPromptRef = useRef('');
  const lastVersionIdRef = useRef<string | null>(null);

  const project = store.activeProject;
  const latestVersion = project?.versions[project.versions.length - 1] ?? null;
  const code = latestVersion?.code ?? '';

  const statusForEmpty = useMemo(() => {
    if (status.kind === 'error') return status.text;
    return '在下方描述你的应用，生成结果会立刻显示在这里。';
  }, [status]);

  const runGeneration = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || isGenerating) return;

    const target = project ?? store.addProject(trimmed.slice(0, 20));
    const isEdit = target.versions.length > 0;
    const currentCode = target.versions[target.versions.length - 1]?.code;

    store.appendMessage(target.id, createMessage('user', trimmed));
    const pending = createMessage('assistant', '');
    store.appendMessage(target.id, pending);
    setPrompt('');
    lastPromptRef.current = trimmed;
    lastVersionIdRef.current = null;
    setStatus({ kind: 'idle', text: 'building…' });
    setMobileLane('preview');

    const startedAt = Date.now();
    try {
      const result = await generate({
        prompt: trimmed,
        mode: isEdit ? 'edit' : 'create',
        appName: target.name,
        currentCode,
        history: target.messages,
      });

      const version = createVersion({
        code: result.code,
        prompt: trimmed,
        summary: result.summary,
        title: result.title,
      });
      store.appendVersion(target.id, version, result.title);
      store.updateMessage(target.id, pending.id, {
        status: 'done',
        content: result.summary,
        versionId: version.id,
      });
      lastVersionIdRef.current = version.id;
      setBuildMs(Date.now() - startedAt);
      setStatus({ kind: 'ready', text: `ready · ${result.model}` });
    } catch (e: any) {
      const message = e?.message || '生成失败，请重试';
      store.updateMessage(target.id, pending.id, { status: 'error', content: message });
      setStatus({ kind: 'error', text: message });
      setBuildMs(null);
    }
  };

  const handleRetry = () => {
    if (!project) return;
    const failed = [...project.messages].reverse().find((message) => message.status === 'error');
    const source =
      lastPromptRef.current ||
      [...project.messages].reverse().find((message) => message.role === 'user')?.content ||
      '';
    if (!source) return;

    if (failed) {
      store.updateMessage(project.id, failed.id, { status: 'pending', content: '' });
    }
    void runGeneration(source);
  };

  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') {
      event.preventDefault();
      void runGeneration(prompt);
    }
  };

  const handleCreate = () => {
    store.addProject();
    setStatus({ kind: 'idle', text: 'idle' });
    setBuildMs(null);
    setMobileLane('chat');
  };

  const composer = (
    <div className="rounded-[14px] border border-border bg-card p-3">
      <label htmlFor="vibe-prompt" className="label-mono text-muted-foreground">
        {project && project.versions.length > 0 ? 'Describe a change' : 'Describe your app'}
      </label>
      <Textarea
        id="vibe-prompt"
        value={prompt}
        onChange={(event) => setPrompt(event.target.value)}
        onKeyDown={handleKeyDown}
        rows={3}
        placeholder={
          project && project.versions.length > 0
            ? '例如：把主色调换成绿色，并加一个重置按钮'
            : '例如：做一个番茄钟计时器，有开始/暂停和专注记录统计'
        }
        className="mt-2 min-h-[76px] resize-none border-0 bg-transparent px-0 text-[14px] shadow-none focus-visible:ring-0"
      />

      {!project?.versions.length && (
        <div className="mb-2 flex flex-wrap gap-1.5">
          {EXAMPLE_PROMPTS.map((example) => (
            <button
              key={example}
              type="button"
              onClick={() => setPrompt(example)}
              className="rounded-full border border-border px-2.5 py-1 text-[12px] text-muted-foreground transition-colors hover:border-primary/60 hover:text-foreground"
            >
              {example}
            </button>
          ))}
        </div>
      )}

      <div className="flex items-center gap-2">
        <span className="label-mono rounded-full bg-muted px-2.5 py-1 text-muted-foreground">claude-opus-5</span>
        <span className="label-mono hidden text-muted-foreground sm:inline">⌘/Ctrl + Enter</span>
        <Button
          onClick={() => void runGeneration(prompt)}
          disabled={isGenerating || !prompt.trim()}
          className="ml-auto h-10 gap-1.5 bg-primary px-4 text-[13px] font-semibold text-primary-foreground hover:bg-[#FF835C]"
        >
          {isGenerating ? <Sparkles className="h-4 w-4 animate-pulse" /> : <ArrowUp className="h-4 w-4" />}
          {isGenerating ? '生成中…' : project?.versions.length ? '应用修改' : '生成应用'}
        </Button>
      </div>
    </div>
  );

  const conversationLane = (
    <section className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-[14px] border border-border bg-card">
      <div className="flex items-center justify-between border-b border-border px-4 py-2.5">
        <span className="label-mono text-muted-foreground">Conversation</span>
        <span className="label-mono text-muted-foreground">
          {project ? `${project.messages.length} 条` : '—'}
        </span>
      </div>
      <ConversationPanel messages={project?.messages ?? []} isGenerating={isGenerating} />
      <div className="border-t border-border p-3">{composer}</div>
    </section>
  );

  const previewLane = (
    <PreviewPanel
      code={code}
      projectName={project?.name ?? 'vibe-app'}
      versionCount={project?.versions.length ?? 0}
      isGenerating={isGenerating}
      status={{ kind: status.kind, text: status.kind === 'idle' && !code ? 'idle' : status.text || statusForEmpty }}
      buildMs={buildMs}
      onRetry={handleRetry}
      canRetry={Boolean(project && lastPromptRef.current)}
    />
  );

  return (
    <div className="min-h-screen bg-background">
      <header className="mx-auto flex max-w-[1800px] items-center gap-3 px-4 py-4">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-primary">
            <Hammer className="h-4.5 w-4.5 text-primary-foreground" strokeWidth={2.4} />
          </span>
          <div>
            <h1 className="font-display text-[17px] font-bold leading-tight">Forge</h1>
            <p className="label-mono text-muted-foreground">vibecoding H5 workbench</p>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <div className="xl:hidden">
            <ProjectMenu
              projects={store.projects}
              activeId={store.activeId}
              activeName={project?.name ?? '未命名项目'}
              onSelect={store.setActiveId}
              onDelete={store.removeProject}
              onCreate={handleCreate}
            />
          </div>
          <div className="flex items-center gap-1 rounded-[10px] bg-muted p-0.5 xl:hidden" role="group" aria-label="视图切换">
            {(['chat', 'preview'] as const).map((lane) => (
              <button
                key={lane}
                type="button"
                onClick={() => setMobileLane(lane)}
                aria-pressed={mobileLane === lane}
                className={cn(
                  'h-9 rounded-[8px] px-3 text-[13px] transition-colors',
                  mobileLane === lane ? 'bg-card text-primary' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {lane === 'chat' ? '对话' : '预览'}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="mx-auto flex max-w-[1800px] gap-4 px-4 pb-5 xl:h-[calc(100vh-88px)]">
        <ProjectRail
          className="hidden w-[248px] shrink-0 xl:flex"
          projects={store.projects}
          activeId={store.activeId}
          onSelect={store.setActiveId}
          onDelete={store.removeProject}
          onCreate={handleCreate}
        />

        <div className={cn('min-h-0 flex-1 xl:flex xl:w-[400px] xl:max-w-[400px]', mobileLane === 'chat' ? 'flex' : 'hidden')}>
          <div className="flex min-h-0 w-full flex-col gap-3 xl:gap-4">
            {conversationLane}
          </div>
        </div>

        <div className={cn('min-h-0 flex-1 xl:flex', mobileLane === 'preview' ? 'flex' : 'hidden')}>
          {previewLane}
        </div>
      </main>
    </div>
  );
};

export default Index;
