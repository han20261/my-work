---
last_updated: 2026-09-30T11:48:09Z
---

# Requirements & Progress

## Requirements Overview

Build a simple iframe H5 app that lets users vibecode through natural language and preview the generated result.

## User Stories

- As a user, I describe an H5 app in natural language and get a working, previewable app.
- As a user, I keep iterating with follow-up natural-language edits and see each new revision.
- As a user, I keep several projects, switch between them, and delete the ones I no longer need.
- As a user, I inspect, copy, download, or open the generated HTML outside the workbench.

## Task Breakdown
| ID | Task | Assignee | Status | Deps |
|----|------|----------|--------|------|
| 1 | Backend generation endpoint (`schemas/vibe.py`, `services/vibe.py`, `routers/vibe.py`) | Alex | done | - |
| 2 | Domain types and localStorage project store | Alex | done | 1 |
| 3 | Generator hook wired to `/api/v1/vibe/generate` | Alex | done | 1 |
| 4 | Conversation panel + composer with create/edit modes | Alex | done | 2,3 |
| 5 | Preview panel: sandboxed iframe, device widths, code view, copy/download/open | Alex | done | 2 |
| 6 | Project rail (create/switch/delete) + compact menu below xl | Alex | done | 2 |
| 7 | Workbench shell with three-lane layout, status strip and retry | Alex | done | 4,5,6 |
| 8 | Lint + build validation | Alex | done | 7 |

## Progress Log

- 2026-09-30 Plan approved; backend and frontend templates initialized.
- 2026-09-30 Reviewed backend README, `web_sdk.md`, `ai_capability.md` for SDK and AI call conventions.
- 2026-09-30 Wrote vibe schema/service/router for the generation endpoint.
- 2026-09-30 Added `DESIGN.md` and the dark ink/coral theme tokens in `index.css`.
- 2026-09-30 Implemented types, localStorage store, generator hook, rail, conversation and preview panels, workbench page.
- 2026-09-30 Recorded architecture and decisions; running lint and build.

