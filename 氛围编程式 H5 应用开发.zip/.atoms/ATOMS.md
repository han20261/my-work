---
last_updated: 2026-09-30T11:48:09Z
status: active
---

# Project Context

## Project Overview

Forge — an iframe-based H5 vibecoding workbench. The user describes an app in natural language, Atoms Cloud generates one self-contained HTML document, and the result previews live in a sandboxed iframe with the source viewable and downloadable. Projects, chat history and all revisions live in browser localStorage.

## Key Decisions
| Date | Decision | By | Rationale |
|------|----------|-----|-----------|
| 2026-09-30 | Generated apps run in a sandboxed `srcDoc` iframe without `allow-same-origin` | Alex | Preview-only requirement; keeps generated scripts isolated from the workbench |
| 2026-09-30 | No database tables; project state in localStorage | Alex | Personal scratch work, no sharing needed; keeps the backend stateless |
| 2026-09-30 | Single AI call returns `TITLE`, `SUMMARY` and one fenced HTML block | Alex | Easy to parse, keeps title/summary in the user's language |
| 2026-09-30 | Edit mode resends current code + recent history instead of server state | Alex | Stateless backend, no session sync |

## Constraints


