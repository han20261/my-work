# Architecture Design

## System Overview

Forge is a vibecoding workbench: the user describes an H5 app in natural language, the Atoms Cloud backend asks a large language model to produce one complete self-contained HTML document, and the frontend renders that document live in a sandboxed iframe.

Three vertical lanes make up the single-page workbench:

1. `ProjectRail` — the list of local projects, each holding its own message thread and generated revisions.
2. `ConversationPanel` — the natural-language dialogue plus the composer that submits create/edit requests.
3. `PreviewPanel` — the live iframe over the latest revision, with device-width switching and a read-only source view.

Generate flow: composer → `POST /api/v1/vibe/generate` → service builds the prompt from mode/history/current code → AI `gentxt` call → HTML extracted from the fenced block → response `{code, title, summary, model}` → new revision stored locally → iframe re-renders via `srcDoc`.

## Tech Stack

| Layer | Choice |
|-------|--------|
| Frontend | React + Vite + TypeScript, shadcn/ui, Tailwind CSS |
| Backend | Atoms Cloud (FastAPI edge service + AI hub) |
| Model | `claude-opus-5` (`gentxt`) for code generation |
| Persistence | Browser `localStorage` (`forge:vibe-projects:v1`) — projects, chat history, all revisions |
| Preview | Sandboxed `<iframe srcDoc>` with a Blob URL fallback for open/download |

## Module Design
| Module | Responsibility | Key Files |
|--------|---------------|-----------|
| Workbench page | Owns generation orchestration, three-lane layout, status strip, retry | `app/frontend/src/pages/Index.tsx` |
| Project rail | Project list, active marker, create/delete, compact dropdown below xl | `app/frontend/src/components/vibe/ProjectRail.tsx` |
| Conversation panel | Renders message thread and building/error states | `app/frontend/src/components/vibe/ConversationPanel.tsx` |
| Preview panel | iframe preview, device widths, reload, copy, open, download, code view, status bar | `app/frontend/src/components/vibe/PreviewPanel.tsx` |
| Local store | Project/message/revision state, persistence, id generation | `app/frontend/src/lib/vibe/store.ts` |
| Domain types | `VibeProject`, `VibeVersion`, `VibeMessage`, device widths, example prompts | `app/frontend/src/lib/vibe/types.ts` |
| Generator hook | Calls the backend endpoint, normalizes errors, tracks loading | `app/frontend/src/lib/vibe/useVibeGenerator.ts` |
| Vibe API | Request/response contract for generation | `app/backend/schemas/vibe.py`, `app/backend/routers/vibe.py` |
| Vibe service | Prompt assembly, HTML extraction, title/summary parsing, model call | `app/backend/services/vibe.py` |

## Tech Decisions
| Decision | Choice | Rationale |
|----------|--------|-----------|
| Where generated apps run | Sandboxed iframe with `srcDoc`, no backend hosting | The requirement is preview-only; `allow-same-origin` is deliberately omitted so generated scripts stay isolated from the host app |
| Storage location | Browser localStorage, no database tables | Projects are personal scratch work with no sharing requirement; this keeps the backend stateless and the deliverable end-to-end without extra tables |
| Generation contract | One `gentxt` call returning `TITLE` / `SUMMARY` + one fenced HTML block | Simple, cheap to parse, and keeps title/summary in the user's language |
| Edit mode | Send current code + recent history as context instead of storing state server-side | Stateless backend, deterministic prompt, no server-side session to keep in sync |
| Model choice | `claude-opus-5` | Best code quality for single-file app generation |

## File Tree Plan

```
app/backend/
  schemas/vibe.py          # GenerateAppRequest / GenerateAppResponse
  services/vibe.py         # prompt + model call + HTML extraction
  routers/vibe.py          # POST /api/v1/vibe/generate
app/frontend/src/
  pages/Index.tsx          # workbench shell + generation orchestration
  components/vibe/
    ProjectRail.tsx        # rail + compact project menu
    ConversationPanel.tsx  # message thread
    PreviewPanel.tsx       # iframe / code / toolbar / status
  lib/vibe/
    types.ts               # domain types + constants
    store.ts               # localStorage-backed project store
    useVibeGenerator.ts    # API hook
```

## Implementation Guide

1. Backend: `POST /api/v1/vibe/generate` accepts `{prompt, mode, app_name?, current_code?, history[]}` and returns `{code, title, summary, model}`; the service strips fenced blocks and falls back to any `<!DOCTYPE html>` payload.
2. Frontend generation: `runGeneration` creates a project on first use, appends the user turn plus a pending assistant turn, calls the hook, then stores a new `VibeVersion` and marks the assistant turn with the returned summary.
3. Preview: revisions are rendered with `srcDoc`; device toggles only change iframe width, reload re-mounts the iframe, and a Blob URL backs open-in-new-tab and download.
4. Errors keep the previous revision visible; the status strip turns destructive and a retry action replays the last prompt.
5. Validation: `pnpm run lint && pnpm run build` in `app/frontend`.
